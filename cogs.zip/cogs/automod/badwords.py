import discord
from discord.ext import commands
import re
import asyncio
from datetime import timedelta
from collections import defaultdict
from utils.Tools import *

# ── Banned words / patterns ──────────────────────────────
BANNED_PATTERNS = [
    r'ni+g+[ae3r]+[s]?',   # nigga, nigger, n1gga, niggggaa etc.
    r'b[i1]tch[e]?[s]?',   # bitch, b1tch, bitches
    r'a+s+h[o0]le[s]?',    # asshole, a55hole etc.
]

COMPILED = [re.compile(p, re.IGNORECASE) for p in BANNED_PATTERNS]

MUTE_DURATION   = 10   # minutes
STRIKE_LIMIT    = 3    # strikes before mute
STRIKE_RESET    = 300  # seconds before strikes reset (5 mins)


def contains_banned_word(text: str) -> bool:
    stripped = re.sub(r'\s+', '', text)
    for pattern in COMPILED:
        if pattern.search(text) or pattern.search(stripped):
            return True
    return False


class BadWords(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        # {guild_id: {user_id: [timestamps]}}
        self.strikes = defaultdict(lambda: defaultdict(list))

    def get_strikes(self, guild_id, user_id):
        now = asyncio.get_event_loop().time()
        self.strikes[guild_id][user_id] = [
            t for t in self.strikes[guild_id][user_id]
            if now - t < STRIKE_RESET
        ]
        return len(self.strikes[guild_id][user_id])

    def add_strike(self, guild_id, user_id):
        now = asyncio.get_event_loop().time()
        self.strikes[guild_id][user_id].append(now)
        return self.get_strikes(guild_id, user_id)

    def clear_strikes(self, guild_id, user_id):
        self.strikes[guild_id][user_id] = []

    async def handle_violation(self, message: discord.Message):
        guild_id = message.guild.id
        user_id  = message.author.id

        try:
            await message.delete()
        except discord.Forbidden:
            pass

        strikes = self.add_strike(guild_id, user_id)

        if strikes >= STRIKE_LIMIT:
            self.clear_strikes(guild_id, user_id)
            try:
                await message.author.timeout(
                    timedelta(minutes=MUTE_DURATION),
                    reason=f"Repeated use of banned words ({STRIKE_LIMIT} strikes)"
                )
                embed = discord.Embed(
                    description=f"🔇 {message.author.mention} has been muted for **{MUTE_DURATION} minutes** for repeatedly using banned words!",
                    color=0xFF0000
                )
            except discord.Forbidden:
                embed = discord.Embed(
                    description=f"⚠️ {message.author.mention} reached {STRIKE_LIMIT} strikes but I don't have permission to mute them!",
                    color=0xFF0000
                )
        else:
            remaining = STRIKE_LIMIT - strikes
            embed = discord.Embed(
                description=f"⚠️ {message.author.mention} Watch your language! That word is not allowed here.\n**Strike {strikes}/{STRIKE_LIMIT}** — {remaining} more will result in a **{MUTE_DURATION} minute mute**!",
                color=0xFF4500
            )

        warning = await message.channel.send(embed=embed)
        await asyncio.sleep(5)
        try:
            await warning.delete()
        except discord.NotFound:
            pass

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if message.author.bot or not message.guild:
            return
        if message.author.guild_permissions.manage_messages:
            return
        if contains_banned_word(message.content):
            await self.handle_violation(message)

    @commands.Cog.listener()
    async def on_message_edit(self, before: discord.Message, after: discord.Message):
        if after.author.bot or not after.guild:
            return
        if after.author.guild_permissions.manage_messages:
            return
        if contains_banned_word(after.content):
            await self.handle_violation(after)


async def setup(bot):
    await bot.add_cog(BadWords(bot))
