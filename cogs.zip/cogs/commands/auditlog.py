import discord
from discord.ext import commands
import aiosqlite
import os
from utils.Tools import *

DB_PATH = "db/auditlog.db"

CATEGORIES = {
    "members":  ["member_join", "member_leave", "member_update", "member_ban", "member_unban"],
    "messages": ["message_delete", "message_edit"],
    "channels": ["channel_create", "channel_delete", "channel_update"],
    "roles":    ["role_create", "role_delete", "role_update"],
    "server":   ["guild_update", "invite_create", "invite_delete"],
    "voice":    ["voice_join", "voice_leave", "voice_move"],
}


class AuditLog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.bot.loop.create_task(self.init_db())

    async def init_db(self):
        os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute("""
                CREATE TABLE IF NOT EXISTS auditlog_channels (
                    guild_id INTEGER,
                    category TEXT,
                    channel_id INTEGER,
                    PRIMARY KEY (guild_id, category)
                )
            """)
            await db.commit()

    async def get_log_channel(self, guild_id, category):
        async with aiosqlite.connect(DB_PATH) as db:
            cursor = await db.execute(
                "SELECT channel_id FROM auditlog_channels WHERE guild_id = ? AND category = ?",
                (guild_id, category)
            )
            row = await cursor.fetchone()
            return row[0] if row else None

    async def send_log(self, guild, category, embed):
        channel_id = await self.get_log_channel(guild.id, category)
        if not channel_id:
            return
        channel = guild.get_channel(channel_id)
        if channel:
            try:
                await channel.send(embed=embed)
            except discord.Forbidden:
                pass

    # ── SETUP ──────────────────────────────────────

    @commands.hybrid_command(name="setuplog", description="Auto-create log channels for every category.")
    @blacklist_check()
    @ignore_check()
    @commands.guild_only()
    @commands.has_permissions(administrator=True)
    @commands.cooldown(1, 10, commands.BucketType.guild)
    async def setuplog(self, ctx):
        await ctx.defer()
        guild = ctx.guild

        log_category = discord.utils.get(guild.categories, name="📋 Audit Logs")
        if not log_category:
            try:
                log_category = await guild.create_category("📋 Audit Logs", reason="Audit log setup")
            except discord.Forbidden:
                return await ctx.send(embed=discord.Embed(description="❌ I don't have permission to create channels!", color=0xFF0000))

        created = []
        async with aiosqlite.connect(DB_PATH) as db:
            for category_name in CATEGORIES:
                cursor = await db.execute(
                    "SELECT channel_id FROM auditlog_channels WHERE guild_id = ? AND category = ?",
                    (guild.id, category_name)
                )
                existing = await cursor.fetchone()
                if existing:
                    ch = guild.get_channel(existing[0])
                    if ch:
                        created.append(f"✅ {ch.mention} (already exists)")
                        continue

                try:
                    overwrites = {
                        guild.default_role: discord.PermissionOverwrite(send_messages=False, read_messages=False),
                        guild.me: discord.PermissionOverwrite(send_messages=True, read_messages=True)
                    }
                    channel = await log_category.create_text_channel(
                        name=f"{category_name}-logs",
                        overwrites=overwrites,
                        reason="Audit log setup"
                    )
                    await db.execute(
                        "INSERT OR REPLACE INTO auditlog_channels (guild_id, category, channel_id) VALUES (?, ?, ?)",
                        (guild.id, category_name, channel.id)
                    )
                    created.append(f"✅ {channel.mention}")
                except Exception as e:
                    created.append(f"❌ {category_name} — {e}")

            await db.commit()

        embed = discord.Embed(title="📋 Audit Log Setup Complete", description="\n".join(created), color=0x000000)
        embed.set_footer(text=f"Setup by {ctx.author}", icon_url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url)
        await ctx.send(embed=embed)

    @commands.hybrid_command(name="setlog", description="Set a specific log channel manually.")
    @blacklist_check()
    @ignore_check()
    @commands.guild_only()
    @commands.has_permissions(administrator=True)
    @commands.cooldown(1, 3, commands.BucketType.guild)
    async def setlog(self, ctx, category: str, channel: discord.TextChannel):
        category = category.lower()
        if category not in CATEGORIES:
            cats = ", ".join(f"`{c}`" for c in CATEGORIES)
            return await ctx.send(embed=discord.Embed(description=f"❌ Invalid category. Choose from: {cats}", color=0xFF0000))
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute(
                "INSERT OR REPLACE INTO auditlog_channels (guild_id, category, channel_id) VALUES (?, ?, ?)",
                (ctx.guild.id, category, channel.id)
            )
            await db.commit()
        await ctx.send(embed=discord.Embed(description=f"✅ **{category}** logs → {channel.mention}", color=0x000000))

    @commands.hybrid_command(name="logconfig", description="View current audit log channel config.")
    @blacklist_check()
    @ignore_check()
    @commands.guild_only()
    @commands.has_permissions(administrator=True)
    @commands.cooldown(1, 3, commands.BucketType.guild)
    async def logconfig(self, ctx):
        async with aiosqlite.connect(DB_PATH) as db:
            cursor = await db.execute("SELECT category, channel_id FROM auditlog_channels WHERE guild_id = ?", (ctx.guild.id,))
            rows = await cursor.fetchall()

        if not rows:
            return await ctx.send(embed=discord.Embed(description="❌ No log channels set. Use `/setuplog` first!", color=0xFF0000))

        embed = discord.Embed(title="📋 Audit Log Config", color=0x000000)
        for category, channel_id in rows:
            ch = ctx.guild.get_channel(channel_id)
            embed.add_field(name=category.capitalize(), value=ch.mention if ch else "Deleted channel", inline=True)
        await ctx.send(embed=embed)

    @commands.hybrid_command(name="disablelog", description="Disable logs for a specific category.")
    @blacklist_check()
    @ignore_check()
    @commands.guild_only()
    @commands.has_permissions(administrator=True)
    @commands.cooldown(1, 3, commands.BucketType.guild)
    async def disablelog(self, ctx, category: str):
        category = category.lower()
        if category not in CATEGORIES:
            cats = ", ".join(f"`{c}`" for c in CATEGORIES)
            return await ctx.send(embed=discord.Embed(description=f"❌ Invalid category. Choose from: {cats}", color=0xFF0000))
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute("DELETE FROM auditlog_channels WHERE guild_id = ? AND category = ?", (ctx.guild.id, category))
            await db.commit()
        await ctx.send(embed=discord.Embed(description=f"✅ Disabled **{category}** logs.", color=0x000000))

    # ── MEMBER EVENTS ──────────────────────────────

    @commands.Cog.listener()
    async def on_member_join(self, member):
        embed = discord.Embed(title="📥 Member Joined", color=0x00FF00)
        embed.set_thumbnail(url=member.avatar.url if member.avatar else member.default_avatar.url)
        embed.add_field(name="User", value=f"{member.mention} ({member})", inline=False)
        embed.add_field(name="ID", value=str(member.id), inline=True)
        embed.add_field(name="Account Created", value=f"<t:{int(member.created_at.timestamp())}:R>", inline=True)
        embed.set_footer(text=f"Member #{member.guild.member_count}")
        await self.send_log(member.guild, "members", embed)

    @commands.Cog.listener()
    async def on_member_remove(self, member):
        embed = discord.Embed(title="📤 Member Left", color=0xFF4500)
        embed.set_thumbnail(url=member.avatar.url if member.avatar else member.default_avatar.url)
        embed.add_field(name="User", value=f"{member.mention} ({member})", inline=False)
        embed.add_field(name="ID", value=str(member.id), inline=True)
        roles = [r.mention for r in member.roles if r.name != "@everyone"]
        embed.add_field(name="Roles", value=", ".join(roles) if roles else "None", inline=False)
        await self.send_log(member.guild, "members", embed)

    @commands.Cog.listener()
    async def on_member_update(self, before, after):
        if before.nick != after.nick:
            embed = discord.Embed(title="✏️ Nickname Changed", color=0xFFFF00)
            embed.add_field(name="User", value=after.mention, inline=False)
            embed.add_field(name="Before", value=before.nick or "None", inline=True)
            embed.add_field(name="After", value=after.nick or "None", inline=True)
            await self.send_log(after.guild, "members", embed)

        if before.roles != after.roles:
            added = [r for r in after.roles if r not in before.roles]
            removed = [r for r in before.roles if r not in after.roles]
            if added or removed:
                embed = discord.Embed(title="🎭 Roles Updated", color=0xFFFF00)
                embed.add_field(name="User", value=after.mention, inline=False)
                if added:
                    embed.add_field(name="Added", value=", ".join(r.mention for r in added), inline=True)
                if removed:
                    embed.add_field(name="Removed", value=", ".join(r.mention for r in removed), inline=True)
                await self.send_log(after.guild, "members", embed)

    @commands.Cog.listener()
    async def on_member_ban(self, guild, user):
        embed = discord.Embed(title="🔨 Member Banned", color=0xFF0000)
        embed.add_field(name="User", value=f"{user.mention} ({user})", inline=False)
        embed.add_field(name="ID", value=str(user.id), inline=True)
        await self.send_log(guild, "members", embed)

    @commands.Cog.listener()
    async def on_member_unban(self, guild, user):
        embed = discord.Embed(title="✅ Member Unbanned", color=0x00FF00)
        embed.add_field(name="User", value=f"{user.mention} ({user})", inline=False)
        embed.add_field(name="ID", value=str(user.id), inline=True)
        await self.send_log(guild, "members", embed)

    # ── MESSAGE EVENTS ─────────────────────────────

    @commands.Cog.listener()
    async def on_message_delete(self, message):
        if message.author.bot or not message.guild:
            return
        embed = discord.Embed(title="🗑️ Message Deleted", color=0xFF4500)
        embed.add_field(name="Author", value=f"{message.author.mention} ({message.author})", inline=False)
        embed.add_field(name="Channel", value=message.channel.mention, inline=True)
        embed.add_field(name="Content", value=message.content[:1024] if message.content else "*No text*", inline=False)
        await self.send_log(message.guild, "messages", embed)

    @commands.Cog.listener()
    async def on_message_edit(self, before, after):
        if before.author.bot or not before.guild:
            return
        if before.content == after.content:
            return
        embed = discord.Embed(title="✏️ Message Edited", color=0xFFFF00)
        embed.add_field(name="Author", value=f"{before.author.mention} ({before.author})", inline=False)
        embed.add_field(name="Channel", value=before.channel.mention, inline=True)
        embed.add_field(name="Before", value=before.content[:512] if before.content else "*No text*", inline=False)
        embed.add_field(name="After", value=after.content[:512] if after.content else "*No text*", inline=False)
        embed.add_field(name="Jump", value=f"[Click here]({after.jump_url})", inline=False)
        await self.send_log(before.guild, "messages", embed)

    # ── CHANNEL EVENTS ─────────────────────────────

    @commands.Cog.listener()
    async def on_guild_channel_create(self, channel):
        embed = discord.Embed(title="📢 Channel Created", color=0x00FF00)
        embed.add_field(name="Name", value=channel.mention, inline=True)
        embed.add_field(name="Type", value=str(channel.type), inline=True)
        await self.send_log(channel.guild, "channels", embed)

    @commands.Cog.listener()
    async def on_guild_channel_delete(self, channel):
        embed = discord.Embed(title="🗑️ Channel Deleted", color=0xFF0000)
        embed.add_field(name="Name", value=f"#{channel.name}", inline=True)
        embed.add_field(name="Type", value=str(channel.type), inline=True)
        await self.send_log(channel.guild, "channels", embed)

    @commands.Cog.listener()
    async def on_guild_channel_update(self, before, after):
        if before.name != after.name:
            embed = discord.Embed(title="✏️ Channel Updated", color=0xFFFF00)
            embed.add_field(name="Before", value=f"#{before.name}", inline=True)
            embed.add_field(name="After", value=after.mention, inline=True)
            await self.send_log(after.guild, "channels", embed)

    # ── ROLE EVENTS ────────────────────────────────

    @commands.Cog.listener()
    async def on_guild_role_create(self, role):
        embed = discord.Embed(title="🎭 Role Created", color=0x00FF00)
        embed.add_field(name="Name", value=role.mention, inline=True)
        embed.add_field(name="Color", value=str(role.color), inline=True)
        await self.send_log(role.guild, "roles", embed)

    @commands.Cog.listener()
    async def on_guild_role_delete(self, role):
        embed = discord.Embed(title="🗑️ Role Deleted", color=0xFF0000)
        embed.add_field(name="Name", value=role.name, inline=True)
        embed.add_field(name="Color", value=str(role.color), inline=True)
        await self.send_log(role.guild, "roles", embed)

    @commands.Cog.listener()
    async def on_guild_role_update(self, before, after):
        if before.name != after.name:
            embed = discord.Embed(title="✏️ Role Updated", color=0xFFFF00)
            embed.add_field(name="Before", value=before.name, inline=True)
            embed.add_field(name="After", value=after.mention, inline=True)
            await self.send_log(after.guild, "roles", embed)

    # ── SERVER EVENTS ──────────────────────────────

    @commands.Cog.listener()
    async def on_guild_update(self, before, after):
        if before.name != after.name:
            embed = discord.Embed(title="🏠 Server Name Changed", color=0xFFFF00)
            embed.add_field(name="Before", value=before.name, inline=True)
            embed.add_field(name="After", value=after.name, inline=True)
            await self.send_log(after, "server", embed)

    @commands.Cog.listener()
    async def on_invite_create(self, invite):
        embed = discord.Embed(title="🔗 Invite Created", color=0x00FF00)
        embed.add_field(name="Code", value=invite.code, inline=True)
        embed.add_field(name="Created By", value=invite.inviter.mention if invite.inviter else "Unknown", inline=True)
        embed.add_field(name="Channel", value=invite.channel.mention, inline=True)
        embed.add_field(name="Max Uses", value=str(invite.max_uses) if invite.max_uses else "Unlimited", inline=True)
        await self.send_log(invite.guild, "server", embed)

    @commands.Cog.listener()
    async def on_invite_delete(self, invite):
        embed = discord.Embed(title="🔗 Invite Deleted", color=0xFF0000)
        embed.add_field(name="Code", value=invite.code, inline=True)
        embed.add_field(name="Channel", value=invite.channel.mention, inline=True)
        await self.send_log(invite.guild, "server", embed)

    # ── VOICE EVENTS ───────────────────────────────

    @commands.Cog.listener()
    async def on_voice_state_update(self, member, before, after):
        if before.channel == after.channel:
            return
        if before.channel is None and after.channel is not None:
            embed = discord.Embed(title="🎙️ Joined Voice", color=0x00FF00)
            embed.add_field(name="User", value=member.mention, inline=True)
            embed.add_field(name="Channel", value=after.channel.mention, inline=True)
            await self.send_log(member.guild, "voice", embed)
        elif before.channel is not None and after.channel is None:
            embed = discord.Embed(title="🔇 Left Voice", color=0xFF4500)
            embed.add_field(name="User", value=member.mention, inline=True)
            embed.add_field(name="Channel", value=before.channel.mention, inline=True)
            await self.send_log(member.guild, "voice", embed)
        else:
            embed = discord.Embed(title="🔀 Moved Voice Channel", color=0xFFFF00)
            embed.add_field(name="User", value=member.mention, inline=True)
            embed.add_field(name="From", value=before.channel.mention, inline=True)
            embed.add_field(name="To", value=after.channel.mention, inline=True)
            await self.send_log(member.guild, "voice", embed)


async def setup(bot):
    await bot.add_cog(AuditLog(bot))
