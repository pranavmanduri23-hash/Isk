import discord
from discord.ext import commands
import yt_dlp
import asyncio
from collections import deque
from utils.Tools import *

YTDL_OPTIONS = {
    'format': 'bestaudio/best',
    'noplaylist': True,
    'default_search': 'auto',
    'quiet': True,
    'no_warnings': True,
}
FFMPEG_OPTIONS = {
    'before_options': '-reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 5',
    'options': '-vn'
}
ytdl = yt_dlp.YoutubeDL(YTDL_OPTIONS)

# ── Per-guild queue ───────────────────────────────────────
queues = {}

def get_queue(guild_id):
    if guild_id not in queues:
        queues[guild_id] = deque()
    return queues[guild_id]


def format_duration(seconds):
    if not seconds:
        return "Live"
    m, s = divmod(int(seconds), 60)
    h, m = divmod(m, 60)
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"


async def play_next(ctx):
    queue = get_queue(ctx.guild.id)
    if not queue:
        return
    info = queue.popleft()
    try:
        source = await discord.FFmpegOpusAudio.from_probe(info['url'], **FFMPEG_OPTIONS)
        ctx.voice_client.play(
            source,
            after=lambda e: asyncio.run_coroutine_threadsafe(play_next(ctx), ctx.bot.loop)
        )
        embed = discord.Embed(
            title="🎵 Now Playing",
            description=f"**[{info['title']}]({info['webpage_url']})**",
            color=0x1DB954
        )
        embed.add_field(name="Duration", value=format_duration(info.get('duration')), inline=True)
        embed.add_field(name="Uploader", value=info.get('uploader', 'Unknown'), inline=True)
        embed.set_thumbnail(url=info.get('thumbnail', ''))
        await ctx.send(embed=embed)
    except Exception as e:
        await ctx.send(f"❌ Error playing track: {e}")


class Music(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    # ── /search ───────────────────────────────────────────
    @commands.hybrid_command(name="search", description="Search for songs and pick one to play.")
    @blacklist_check()
    @ignore_check()
    @commands.guild_only()
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def search(self, ctx, *, query: str):
        await ctx.defer()

        if not ctx.author.voice:
            return await ctx.send(embed=discord.Embed(description="❌ Join a voice channel first!", color=0xFF0000))

        try:
            results = ytdl.extract_info(f"ytsearch5:{query}", download=False)['entries']
        except Exception as e:
            return await ctx.send(embed=discord.Embed(description=f"❌ Search failed: {e}", color=0xFF0000))

        if not results:
            return await ctx.send(embed=discord.Embed(description="❌ No results found!", color=0xFF0000))

        # Build search results embed
        embed = discord.Embed(
            title=f"🔍 Search Results for: {query}",
            description="Pick a song by clicking a button below!",
            color=0x1DB954
        )
        for i, entry in enumerate(results, 1):
            duration = format_duration(entry.get('duration'))
            embed.add_field(
                name=f"{i}. {entry['title']}",
                value=f"⏱️ {duration} | 👤 {entry.get('uploader', 'Unknown')}",
                inline=False
            )

        # Build buttons
        view = discord.ui.View(timeout=30)
        for i, entry in enumerate(results, 1):
            btn = discord.ui.Button(label=str(i), style=discord.ButtonStyle.blurple)

            async def callback(interaction, e=entry):
                if interaction.user != ctx.author:
                    return await interaction.response.send_message("❌ Only the requester can pick!", ephemeral=True)
                await interaction.response.defer()
                queue = get_queue(ctx.guild.id)
                queue.append(e)
                if not ctx.voice_client:
                    await ctx.author.voice.channel.connect()
                if not ctx.voice_client.is_playing():
                    await play_next(ctx)
                else:
                    await ctx.send(embed=discord.Embed(
                        description=f"➕ Added to queue: **{e['title']}**",
                        color=0x1DB954
                    ))

            btn.callback = callback
            view.add_item(btn)

        await ctx.send(embed=embed, view=view)

    # ── /play ─────────────────────────────────────────────
    @commands.hybrid_command(name="play", description="Play a song directly by name or URL.")
    @blacklist_check()
    @ignore_check()
    @commands.guild_only()
    @commands.cooldown(1, 3, commands.BucketType.user)
    async def play(self, ctx, *, query: str):
        await ctx.defer()

        if not ctx.author.voice:
            return await ctx.send(embed=discord.Embed(description="❌ Join a voice channel first!", color=0xFF0000))

        try:
            info = ytdl.extract_info(f"ytsearch:{query}", download=False)
            if 'entries' in info:
                info = info['entries'][0]
        except Exception as e:
            return await ctx.send(embed=discord.Embed(description=f"❌ Error: {e}", color=0xFF0000))

        if not ctx.voice_client:
            await ctx.author.voice.channel.connect()

        queue = get_queue(ctx.guild.id)
        queue.append(info)

        if not ctx.voice_client.is_playing():
            await play_next(ctx)
        else:
            await ctx.send(embed=discord.Embed(
                description=f"➕ Added to queue: **{info['title']}**",
                color=0x1DB954
            ))

    # ── /queue ────────────────────────────────────────────
    @commands.hybrid_command(name="queue", description="Show the current music queue.")
    @blacklist_check()
    @ignore_check()
    @commands.guild_only()
    @commands.cooldown(1, 3, commands.BucketType.user)
    async def queue(self, ctx):
        queue = get_queue(ctx.guild.id)
        if not queue:
            return await ctx.send(embed=discord.Embed(description="📭 Queue is empty!", color=0xFF0000))

        lines = [f"`{i}.` **{e['title']}** — {format_duration(e.get('duration'))}"
                 for i, e in enumerate(queue, 1)]
        embed = discord.Embed(title="🎶 Music Queue", description="\n".join(lines[:10]), color=0x1DB954)
        embed.set_footer(text=f"{len(queue)} song(s) in queue")
        await ctx.send(embed=embed)

    # ── /skip ─────────────────────────────────────────────
    @commands.hybrid_command(name="skip", description="Skip the current song.")
    @blacklist_check()
    @ignore_check()
    @commands.guild_only()
    @commands.cooldown(1, 3, commands.BucketType.user)
    async def skip(self, ctx):
        if not ctx.voice_client or not ctx.voice_client.is_playing():
            return await ctx.send(embed=discord.Embed(description="❌ Nothing is playing!", color=0xFF0000))
        ctx.voice_client.stop()
        await ctx.send(embed=discord.Embed(description="⏭️ Skipped!", color=0x1DB954))

    # ── /pause ────────────────────────────────────────────
    @commands.hybrid_command(name="pause", description="Pause the current song.")
    @blacklist_check()
    @ignore_check()
    @commands.guild_only()
    @commands.cooldown(1, 3, commands.BucketType.user)
    async def pause(self, ctx):
        if ctx.voice_client and ctx.voice_client.is_playing():
            ctx.voice_client.pause()
            await ctx.send(embed=discord.Embed(description="⏸️ Paused!", color=0x1DB954))
        else:
            await ctx.send(embed=discord.Embed(description="❌ Nothing is playing!", color=0xFF0000))

    # ── /resume ───────────────────────────────────────────
    @commands.hybrid_command(name="resume", description="Resume the paused song.")
    @blacklist_check()
    @ignore_check()
    @commands.guild_only()
    @commands.cooldown(1, 3, commands.BucketType.user)
    async def resume(self, ctx):
        if ctx.voice_client and ctx.voice_client.is_paused():
            ctx.voice_client.resume()
            await ctx.send(embed=discord.Embed(description="▶️ Resumed!", color=0x1DB954))
        else:
            await ctx.send(embed=discord.Embed(description="❌ Nothing is paused!", color=0xFF0000))

    # ── /stop ─────────────────────────────────────────────
    @commands.hybrid_command(name="stop", description="Stop music and disconnect.")
    @blacklist_check()
    @ignore_check()
    @commands.guild_only()
    @commands.cooldown(1, 3, commands.BucketType.user)
    async def stop(self, ctx):
        if ctx.voice_client:
            queues.pop(ctx.guild.id, None)
            await ctx.voice_client.disconnect()
            await ctx.send(embed=discord.Embed(description="👋 Disconnected and cleared queue.", color=0x1DB954))
        else:
            await ctx.send(embed=discord.Embed(description="❌ I'm not in a voice channel.", color=0xFF0000))

    # ── /clearqueue ───────────────────────────────────────
    @commands.hybrid_command(name="clearqueue", description="Clear the music queue.")
    @blacklist_check()
    @ignore_check()
    @commands.guild_only()
    @commands.cooldown(1, 3, commands.BucketType.user)
    async def clearqueue(self, ctx):
        queues.pop(ctx.guild.id, None)
        await ctx.send(embed=discord.Embed(description="🗑️ Queue cleared!", color=0x1DB954))


async def setup(bot):
    await bot.add_cog(Music(bot))
