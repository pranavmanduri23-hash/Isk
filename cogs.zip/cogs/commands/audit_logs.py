import discord
from discord.ext import commands

class AuditLogger(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        # Define the categories and channel names you want
        self.log_structure = {
            "MONARCH AUDITS": [
                "mod-logs",
                "message-logs",
                "member-logs",
                "server-updates"
            ]
        }

    @commands.Cog.listener()
    async def on_ready(self):
        """Automatically creates the log channels when the bot starts"""
        for guild in self.bot.guilds:
            await self.setup_logs(guild)

    async def setup_logs(self, guild):
        for category_name, channels in self.log_structure.items():
            # 1. Find or Create Category
            category = discord.utils.get(guild.categories, name=category_name)
            if category is None:
                # Set permissions: Private for everyone, visible to Administrators
                overwrites = {
                    guild.default_role: discord.PermissionOverwrite(view_channel=False),
                    guild.me: discord.PermissionOverwrite(view_channel=True)
                }
                category = await guild.create_category(category_name, overwrites=overwrites)
                print(f"✅ Created Category: {category_name} in {guild.name}")

            # 2. Find or Create Channels
            for channel_name in channels:
                existing_channel = discord.utils.get(category.text_channels, name=channel_name)
                if existing_channel is None:
                    await guild.create_text_channel(channel_name, category=category)
                    print(f"   + Created Channel: {channel_name}")

    # --- EXAMPLE LOGGING EVENT ---
    @commands.Cog.listener()
    async def on_message_delete(self, message):
        if message.author.bot: return
        
        channel = discord.utils.get(message.guild.text_channels, name="message-logs")
        if channel:
            embed = discord.Embed(
                title="🗑️ Message Deleted",
                description=f"**Author:** {message.author.mention}\n**Channel:** {message.channel.mention}",
                color=discord.Color.red()
            )
            embed.add_field(name="Content:", value=message.content or "No text content")
            await channel.send(embed=embed)

async def setup(bot):
    await bot.add_cog(AuditLogger(bot))