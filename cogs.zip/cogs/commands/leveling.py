import discord
from discord.ext import commands
import json, os, time, math, random
from utils.Tools import *

DB_FILE         = "/home/container/db/levels.json"
CONFIG_FILE     = "/home/container/db/levels_config.json"
XP_PER_MESSAGE  = 15
XP_COOLDOWN     = 60

# ── DB helpers ───────────────────────────────────────────

def load_db():
    if not os.path.exists(DB_FILE):
        return {}
    with open(DB_FILE) as f:
        return json.load(f)

def save_db(db):
    os.makedirs(os.path.dirname(DB_FILE), exist_ok=True)
    with open(DB_FILE, "w") as f:
        json.dump(db, f, indent=2)

def load_config():
    if not os.path.exists(CONFIG_FILE):
        return {}
    with open(CONFIG_FILE) as f:
        return json.load(f)

def save_config(config):
    os.makedirs(os.path.dirname(CONFIG_FILE), exist_ok=True)
    with open(CONFIG_FILE, "w") as f:
        json.dump(config, f, indent=2)

# ── Math ─────────────────────────────────────────────────

def xp_for_level(level):
    return math.floor(100 * (level ** 1.5))

def get_level(xp):
    level = 1
    while xp >= xp_for_level(level + 1):
        level += 1
    return level

def xp_for_exact_level(level):
    return xp_for_level(level)

def progress_bar(current, total, length=10):
    filled = int((current / total) * length)
    return "█" * filled + "░" * (length - filled)


class Leveling(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    # ── XP on message ────────────────────────────────────

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author.bot or not message.guild:
            return

        uid  = str(message.author.id)
        gid  = str(message.guild.id)
        db   = load_db()
        now  = time.time()

        if uid not in db:
            db[uid] = {"username": str(message.author), "xp": 0, "level": 1, "last_msg": 0}

        entry = db[uid]

        if now - entry["last_msg"] < XP_COOLDOWN:
            return

        entry["username"]  = str(message.author)
        entry["xp"]       += random.randint(10, 25)
        entry["last_msg"]  = now

        old_level = entry["level"]
        new_level = get_level(entry["xp"])
        entry["level"] = new_level
        save_db(db)

        if new_level > old_level:
            config     = load_config()
            channel_id = config.get(gid, {}).get("levelup_channel")
            channel    = message.guild.get_channel(int(channel_id)) if channel_id else message.channel

            embed = discord.Embed(
                description=f"🎉 {message.author.mention} leveled up to **Level {new_level}**!",
                color=0x5865F2
            )
            try:
                await channel.send(embed=embed)
            except Exception:
                pass

    # ── ?rank ─────────────────────────────────────────────

    @commands.hybrid_command(name="rank", description="Check your or someone's rank.")
    @blacklist_check()
    @ignore_check()
    @commands.guild_only()
    @commands.cooldown(1, 3, commands.BucketType.user)
    async def rank(self, ctx, member: discord.Member = None):
        member = member or ctx.author
        db     = load_db()
        uid    = str(member.id)

        if uid not in db:
            return await ctx.send(embed=discord.Embed(description=f"{member.mention} has no XP yet!", color=0xFF0000))

        entry   = db[uid]
        level   = entry["level"]
        xp      = entry["xp"]
        needed  = xp_for_level(level + 1)
        sorted_ = sorted(db.values(), key=lambda u: u["xp"], reverse=True)
        rank    = next((i+1 for i, u in enumerate(sorted_) if u.get("username") == entry["username"]), "?")
        bar     = progress_bar(xp, needed)

        embed = discord.Embed(title=f"📊 {entry['username']}", color=0x5865F2)
        embed.set_thumbnail(url=member.avatar.url if member.avatar else member.default_avatar.url)
        embed.add_field(name="Rank",     value=f"#{rank}",       inline=True)
        embed.add_field(name="Level",    value=level,            inline=True)
        embed.add_field(name="XP",       value=f"{xp}/{needed}", inline=True)
        embed.add_field(name="Progress", value=bar,              inline=False)
        await ctx.send(embed=embed)

    # ── ?leaderboard ──────────────────────────────────────

    @commands.hybrid_command(name="leaderboard", aliases=["lb", "top"], description="See the XP leaderboard.")
    @blacklist_check()
    @ignore_check()
    @commands.guild_only()
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def leaderboard(self, ctx):
        db     = load_db()
        top    = sorted(db.values(), key=lambda u: u["xp"], reverse=True)[:10]
        medals = {1: "🥇", 2: "🥈", 3: "🥉"}
        lines  = [
            f"{medals.get(i, f'`{i}.`')} **{u['username']}** — Lv.{u['level']} ({u['xp']} XP)"
            for i, u in enumerate(top, 1)
        ]
        embed = discord.Embed(title="🏆 Leaderboard", description="\n".join(lines) or "Empty!", color=0xFFD700)
        await ctx.send(embed=embed)

    # ── ?setlevelchannel ──────────────────────────────────

    @commands.hybrid_command(name="setlevelchannel", description="Set the channel for level up messages.")
    @blacklist_check()
    @ignore_check()
    @commands.guild_only()
    @commands.has_permissions(manage_guild=True)
    @commands.cooldown(1, 3, commands.BucketType.guild)
    async def setlevelchannel(self, ctx, channel: discord.TextChannel):
        config = load_config()
        gid    = str(ctx.guild.id)
        if gid not in config:
            config[gid] = {}
        config[gid]["levelup_channel"] = str(channel.id)
        save_config(config)
        await ctx.send(embed=discord.Embed(
            description=f"✅ Level up messages will now be sent to {channel.mention}!",
            color=0x000000
        ))

    # ── ?resetlevelchannel ────────────────────────────────

    @commands.hybrid_command(name="resetlevelchannel", description="Reset level up messages to the same channel.")
    @blacklist_check()
    @ignore_check()
    @commands.guild_only()
    @commands.has_permissions(manage_guild=True)
    @commands.cooldown(1, 3, commands.BucketType.guild)
    async def resetlevelchannel(self, ctx):
        config = load_config()
        gid    = str(ctx.guild.id)
        if gid in config and "levelup_channel" in config[gid]:
            del config[gid]["levelup_channel"]
            save_config(config)
        await ctx.send(embed=discord.Embed(
            description="✅ Level up messages will now be sent in the same channel as the message.",
            color=0x000000
        ))

    # ── ?addlevel ─────────────────────────────────────────

    @commands.hybrid_command(name="addlevel", description="Add levels to a member. (Admin only)")
    @blacklist_check()
    @ignore_check()
    @commands.guild_only()
    @commands.has_permissions(administrator=True)
    @commands.cooldown(1, 3, commands.BucketType.user)
    async def addlevel(self, ctx, member: discord.Member, levels: int):
        if levels <= 0:
            return await ctx.send(embed=discord.Embed(description="❌ Levels must be a positive number!", color=0xFF0000))

        db  = load_db()
        uid = str(member.id)

        if uid not in db:
            db[uid] = {"username": str(member), "xp": 0, "level": 1, "last_msg": 0}

        entry     = db[uid]
        new_level = min(entry["level"] + levels, 500)
        entry["xp"]       = xp_for_exact_level(new_level)
        entry["level"]    = new_level
        entry["username"] = str(member)
        save_db(db)

        await ctx.send(embed=discord.Embed(
            description=f"✅ Added **{levels}** level(s) to {member.mention}. They are now **Level {new_level}**!",
            color=0x000000
        ))

    # ── ?removelevel ──────────────────────────────────────

    @commands.hybrid_command(name="removelevel", description="Remove levels from a member. (Admin only)")
    @blacklist_check()
    @ignore_check()
    @commands.guild_only()
    @commands.has_permissions(administrator=True)
    @commands.cooldown(1, 3, commands.BucketType.user)
    async def removelevel(self, ctx, member: discord.Member, levels: int):
        if levels <= 0:
            return await ctx.send(embed=discord.Embed(description="❌ Levels must be a positive number!", color=0xFF0000))

        db  = load_db()
        uid = str(member.id)

        if uid not in db:
            return await ctx.send(embed=discord.Embed(description=f"{member.mention} has no XP yet!", color=0xFF0000))

        entry     = db[uid]
        new_level = max(entry["level"] - levels, 1)
        entry["xp"]       = xp_for_exact_level(new_level)
        entry["level"]    = new_level
        entry["username"] = str(member)
        save_db(db)

        await ctx.send(embed=discord.Embed(
            description=f"✅ Removed **{levels}** level(s) from {member.mention}. They are now **Level {new_level}**!",
            color=0x000000
        ))

    # ── ?resetlevel ───────────────────────────────────────

    @commands.hybrid_command(name="resetlevel", description="Reset a member's level and XP. (Admin only)")
    @blacklist_check()
    @ignore_check()
    @commands.guild_only()
    @commands.has_permissions(administrator=True)
    @commands.cooldown(1, 3, commands.BucketType.user)
    async def resetlevel(self, ctx, member: discord.Member):
        db  = load_db()
        uid = str(member.id)

        if uid not in db:
            return await ctx.send(embed=discord.Embed(description=f"{member.mention} has no XP yet!", color=0xFF0000))

        db[uid]["xp"]    = 0
        db[uid]["level"] = 1
        save_db(db)

        await ctx.send(embed=discord.Embed(
            description=f"✅ Reset {member.mention}'s level and XP back to Level 1.",
            color=0x000000
        ))


async def setup(bot):
    await bot.add_cog(Leveling(bot))
