import discord
from discord.ext import commands
import aiosqlite
import os
import time
from typing import Optional
from utils.Tools import *

black1 = 0
black2 = 0
black3 = 0

DB_PATH = "db/afk.db"

class BasicView(discord.ui.View):
    def __init__(self, ctx: commands.Context, timeout: Optional[int] = None):
        super().__init__(timeout=timeout)
        self.ctx = ctx

    async def interaction_check(self, interaction: discord.Interaction):
        if interaction.user.id != self.ctx.author.id:
            await interaction.response.send_message(
                embed=discord.Embed(
                    description=f"Only **{self.ctx.author}** can use this command. Use {self.ctx.prefix}**{self.ctx.command}** to run the command",
                    color=self.ctx.author.color
                ), ephemeral=True)
            return False
        return True

class OnOrOff(BasicView):
    def __init__(self, ctx: commands.Context):
        super().__init__(ctx, timeout=30)
        self.value = None

    @discord.ui.button(label="DM me", emoji="✅", custom_id='Yes', style=discord.ButtonStyle.green)
    async def dare(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.value = 'Yes'
        await interaction.response.defer()
        self.stop()

    @discord.ui.button(label="Don't DM", emoji="❌", custom_id='No', style=discord.ButtonStyle.danger)
    async def truth(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.value = 'No'
        await interaction.response.defer()
        self.stop()


class afk(commands.Cog):

    def __init__(self, client, *args, **kwargs):
        self.client = client
        self.client.loop.create_task(self.initialize_db())

    async def initialize_db(self):
        os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute("""
                CREATE TABLE IF NOT EXISTS afk (
                    user_id INTEGER PRIMARY KEY,
                    AFK TEXT NOT NULL,
                    reason TEXT NOT NULL,
                    time INTEGER NOT NULL,
                    mentions INTEGER NOT NULL,
                    dm TEXT NOT NULL
                )
            """)
            await db.execute("""
                CREATE TABLE IF NOT EXISTS afk_guild (
                    user_id INTEGER NOT NULL,
                    guild_id INTEGER NOT NULL,
                    PRIMARY KEY (user_id, guild_id)
                )
            """)
            await db.commit()

    async def cog_after_invoke(self, ctx):
        ctx.command.reset_cooldown(ctx)

    async def update_data(self, user, guild_id):
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute("INSERT OR IGNORE INTO afk (user_id, AFK, reason, time, mentions, dm) VALUES (?, 'False', 'None', 0, 0, 'False')", (user.id,))
            await db.execute("INSERT OR IGNORE INTO afk_guild (user_id, guild_id) VALUES (?, ?)", (user.id, guild_id))
            await db.commit()

    async def time_formatter(self, seconds: float):
        minutes, seconds = divmod(int(seconds), 60)
        hours, minutes = divmod(minutes, 60)
        days, hours = divmod(hours, 24)
        tmp = ((str(days) + " days, ") if days else "") + \
              ((str(hours) + " hours, ") if hours else "") + \
              ((str(minutes) + " minutes, ") if minutes else "") + \
              ((str(seconds) + " seconds, ") if seconds else "")
        return tmp[:-2] if tmp else "0 seconds"

    # ✅ FIXED: was @commands.hybrid_command which broke everything
    @commands.Cog.listener()
    async def on_message(self, message):
        try:
            if message.author.bot:
                return
            if not message.guild:
                return

            async with aiosqlite.connect(DB_PATH) as db:
                # ── Check if the message author is AFK → remove AFK ──
                cursor = await db.execute("SELECT AFK, time, mentions, reason FROM afk WHERE user_id = ?", (message.author.id,))
                afk_data = await cursor.fetchone()
                await cursor.close()

                if afk_data and afk_data[0] == 'True':
                    cursor = await db.execute("SELECT guild_id FROM afk_guild WHERE user_id = ?", (message.author.id,))
                    guild_ids = [row[0] for row in await cursor.fetchall()]
                    await cursor.close()

                    if message.guild.id in guild_ids:
                        meth = int(time.time()) - int(afk_data[1])
                        been_afk_for = await self.time_formatter(meth)
                        mentionz = afk_data[2]
                        await db.execute("UPDATE afk SET AFK = 'False', reason = 'None' WHERE user_id = ?", (message.author.id,))
                        await db.execute("DELETE FROM afk_guild WHERE user_id = ? AND guild_id = ?", (message.author.id, message.guild.id))
                        await db.commit()
                        wlbat = discord.Embed(
                            title=f'{message.author.display_name} Welcome Back!',
                            description=f'I removed your AFK\nTotal Mentions: **{mentionz}**\nAFK Duration: **{been_afk_for}**',
                            color=0x000000
                        )
                        try:
                            await message.reply(embed=wlbat)
                        except discord.Forbidden:
                            pass

                # ── Check if any mentioned user is AFK ──
                if message.mentions:
                    for user_mention in message.mentions:
                        if user_mention.bot:
                            continue

                        cursor = await db.execute("SELECT AFK, reason, time, mentions, dm FROM afk WHERE user_id = ?", (user_mention.id,))
                        afk_data = await cursor.fetchone()
                        await cursor.close()

                        if afk_data and afk_data[0] == 'True':
                            cursor = await db.execute("SELECT guild_id FROM afk_guild WHERE user_id = ?", (user_mention.id,))
                            guild_ids = [row[0] for row in await cursor.fetchall()]
                            await cursor.close()

                            if message.guild.id in guild_ids:
                                reason = afk_data[1]
                                afk_time = afk_data[2]
                                wl = discord.Embed(
                                    description=f'**{user_mention.mention}** went AFK <t:{afk_time}:R> for the following reason:\n**{reason}**',
                                    color=0x000000
                                )
                                try:
                                    await message.reply(embed=wl)
                                except discord.Forbidden:
                                    pass

                                new_mentions = afk_data[3] + 1
                                await db.execute("UPDATE afk SET mentions = ? WHERE user_id = ?", (new_mentions, user_mention.id))
                                await db.commit()

                                # ── DM the AFK user if they opted in ──
                                if afk_data[4] == 'True':
                                    embed = discord.Embed(
                                        description=f'You were mentioned in **{message.guild.name}** by **{message.author}**',
                                        color=0x000000
                                    )
                                    embed.add_field(name="Total Mentions:", value=str(new_mentions), inline=False)
                                    embed.add_field(name="Message:", value=message.content or "*No text*", inline=False)
                                    embed.add_field(name="Jump to Message:", value=f"[Click here]({message.jump_url})", inline=False)
                                    try:
                                        await user_mention.send(embed=embed)
                                    except discord.Forbidden:
                                        pass

            if not message.author.bot:
                await self.update_data(message.author, message.guild.id)

        except Exception as e:
            print(f"Ignoring exception in AFK on_message: {e}")

    @commands.hybrid_command(description="Shows an AFK status when you're mentioned")
    @blacklist_check()
    @ignore_check()
    @commands.guild_only()
    @commands.cooldown(1, 2, commands.BucketType.user)
    async def afk(self, ctx, *, reason=None):
        if not reason:
            reason = "I am AFK 💤"

        if any(invite in reason.lower() for invite in ['discord.gg', 'gg/']):
            emd = discord.Embed(description="❌ You can't advertise a server invite in your AFK reason.", color=0x000000)
            return await ctx.send(embed=emd)

        view = OnOrOff(ctx)
        em = discord.Embed(description="Should I DM you when someone mentions you?", color=0x000000)
        try:
            em.set_author(name=str(ctx.author), icon_url=ctx.author.avatar.url)
        except:
            em.set_author(name=str(ctx.author))

        test = await ctx.reply(embed=em, view=view)
        await view.wait()

        if not view.value:
            return await test.edit(content="Timed out, please try again.", embed=None, view=None)

        dm_status = 'True' if view.value == 'Yes' else 'False'

        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute(
                "INSERT OR REPLACE INTO afk (user_id, AFK, reason, time, mentions, dm) VALUES (?, 'True', ?, ?, 0, ?)",
                (ctx.author.id, reason, int(time.time()), dm_status)
            )
            await db.execute(
                "INSERT OR IGNORE INTO afk_guild (user_id, guild_id) VALUES (?, ?)",
                (ctx.author.id, ctx.guild.id)
            )
            await db.commit()

        await test.delete()
        af = discord.Embed(
            title='✅ AFK Set',
            description=f'{ctx.author.mention}, You are now marked as AFK\nReason: **{reason}**',
            color=0x000000
        )
        await ctx.reply(embed=af)
