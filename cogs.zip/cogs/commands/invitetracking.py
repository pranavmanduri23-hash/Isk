import discord
from discord.ext import commands
import aiosqlite
import os
from utils.Tools import *

DB_PATH = "db/invites.db"


class InviteTracking(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.invite_cache = {}  # guild_id -> {code: invite}
        self.bot.loop.create_task(self.init_db())
        self.bot.loop.create_task(self.cache_invites())

    async def init_db(self):
        os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute("""
                CREATE TABLE IF NOT EXISTS invites (
                    guild_id INTEGER,
                    inviter_id INTEGER,
                    invites INTEGER DEFAULT 0,
                    fake INTEGER DEFAULT 0,
                    left INTEGER DEFAULT 0,
                    PRIMARY KEY (guild_id, inviter_id)
                )
            """)
            await db.execute("""
                CREATE TABLE IF NOT EXISTS invite_uses (
                    guild_id INTEGER,
                    member_id INTEGER,
                    inviter_id INTEGER,
                    PRIMARY KEY (guild_id, member_id)
                )
            """)
            await db.commit()

    async def cache_invites(self):
        await self.bot.wait_until_ready()
        for guild in self.bot.guilds:
            try:
                invites = await guild.invites()
                self.invite_cache[guild.id] = {inv.code: inv for inv in invites}
            except Exception:
                pass

    def get_invite_count(self, invites, total, fake, left):
        return max(0, total - fake - left)

    @commands.Cog.listener()
    async def on_invite_create(self, invite):
        if invite.guild.id not in self.invite_cache:
            self.invite_cache[invite.guild.id] = {}
        self.invite_cache[invite.guild.id][invite.code] = invite

    @commands.Cog.listener()
    async def on_invite_delete(self, invite):
        if invite.guild.id in self.invite_cache:
            self.invite_cache[invite.guild.id].pop(invite.code, None)

    @commands.Cog.listener()
    async def on_member_join(self, member):
        guild = member.guild
        try:
            new_invites = await guild.invites()
            new_cache = {inv.code: inv for inv in new_invites}
            old_cache = self.invite_cache.get(guild.id, {})

            inviter = None
            for code, invite in new_cache.items():
                old = old_cache.get(code)
                if old and invite.uses > old.uses:
                    inviter = invite.inviter
                    break

            self.invite_cache[guild.id] = new_cache

            if inviter:
                async with aiosqlite.connect(DB_PATH) as db:
                    await db.execute("""
                        INSERT INTO invites (guild_id, inviter_id, invites)
                        VALUES (?, ?, 1)
                        ON CONFLICT(guild_id, inviter_id)
                        DO UPDATE SET invites = invites + 1
                    """, (guild.id, inviter.id))
                    await db.execute("""
                        INSERT OR IGNORE INTO invite_uses (guild_id, member_id, inviter_id)
                        VALUES (?, ?, ?)
                    """, (guild.id, member.id, inviter.id))
                    await db.commit()

        except Exception as e:
            print(f"InviteTracking on_member_join error: {e}")

    @commands.Cog.listener()
    async def on_member_remove(self, member):
        guild = member.guild
        try:
            async with aiosqlite.connect(DB_PATH) as db:
                cursor = await db.execute(
                    "SELECT inviter_id FROM invite_uses WHERE guild_id = ? AND member_id = ?",
                    (guild.id, member.id)
                )
                row = await cursor.fetchone()
                if row:
                    inviter_id = row[0]
                    await db.execute("""
                        INSERT INTO invites (guild_id, inviter_id, left)
                        VALUES (?, ?, 1)
                        ON CONFLICT(guild_id, inviter_id)
                        DO UPDATE SET left = left + 1
                    """, (guild.id, inviter_id))
                    await db.commit()
        except Exception as e:
            print(f"InviteTracking on_member_remove error: {e}")

    @commands.hybrid_command(name="invites", description="Check how many people you or someone else has invited.")
    @blacklist_check()
    @ignore_check()
    @commands.guild_only()
    @commands.cooldown(1, 3, commands.BucketType.user)
    async def invites(self, ctx, member: discord.Member = None):
        member = member or ctx.author
        async with aiosqlite.connect(DB_PATH) as db:
            cursor = await db.execute(
                "SELECT invites, fake, left FROM invites WHERE guild_id = ? AND inviter_id = ?",
                (ctx.guild.id, member.id)
            )
            row = await cursor.fetchone()

        if not row:
            total, fake, left = 0, 0, 0
        else:
            total, fake, left = row

        real = max(0, total - fake - left)

        embed = discord.Embed(
            title=f"📨 Invites for {member.display_name}",
            description=f"**{member.mention}** has **{real}** invite(s)!",
            color=0x000000
        )
        embed.add_field(name="✅ Total", value=str(total), inline=True)
        embed.add_field(name="❌ Left", value=str(left), inline=True)
        embed.add_field(name="⚠️ Fake", value=str(fake), inline=True)
        embed.set_thumbnail(url=member.avatar.url if member.avatar else member.default_avatar.url)
        embed.set_footer(
            text=f"Requested by {ctx.author}",
            icon_url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url
        )
        await ctx.send(embed=embed)

    @commands.hybrid_command(name="inviteleaderboard", aliases=["invitelb", "invitetop"], description="See who has the most invites in the server.")
    @blacklist_check()
    @ignore_check()
    @commands.guild_only()
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def inviteleaderboard(self, ctx):
        async with aiosqlite.connect(DB_PATH) as db:
            cursor = await db.execute(
                "SELECT inviter_id, invites, fake, left FROM invites WHERE guild_id = ? ORDER BY invites DESC LIMIT 10",
                (ctx.guild.id,)
            )
            rows = await cursor.fetchall()

        if not rows:
            return await ctx.send(embed=discord.Embed(description="No invite data yet!", color=0x000000))

        medals = {1: "🥇", 2: "🥈", 3: "🥉"}
        lines = []
        for i, (inviter_id, total, fake, left) in enumerate(rows, 1):
            real = max(0, total - fake - left)
            member = ctx.guild.get_member(inviter_id)
            name = member.display_name if member else f"Unknown ({inviter_id})"
            icon = medals.get(i, f"`{i}.`")
            lines.append(f"{icon} **{name}** — {real} invite(s)")

        embed = discord.Embed(
            title="📨 Invite Leaderboard",
            description="\n".join(lines),
            color=0x000000
        )
        embed.set_footer(
            text=f"Requested by {ctx.author}",
            icon_url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url
        )
        await ctx.send(embed=embed)

    @commands.hybrid_command(name="resetinvites", description="Reset a member's invite count.")
    @blacklist_check()
    @ignore_check()
    @commands.guild_only()
    @commands.has_permissions(administrator=True)
    @commands.cooldown(1, 3, commands.BucketType.user)
    async def resetinvites(self, ctx, member: discord.Member):
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute(
                "DELETE FROM invites WHERE guild_id = ? AND inviter_id = ?",
                (ctx.guild.id, member.id)
            )
            await db.commit()
        await ctx.send(embed=discord.Embed(
            description=f"✅ Reset invite count for {member.mention}.",
            color=0x000000
        ))

    @commands.hybrid_command(name="resetallinvites", description="Reset ALL invite counts in the server.")
    @blacklist_check()
    @ignore_check()
    @commands.guild_only()
    @commands.has_permissions(administrator=True)
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def resetallinvites(self, ctx):
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute("DELETE FROM invites WHERE guild_id = ?", (ctx.guild.id,))
            await db.execute("DELETE FROM invite_uses WHERE guild_id = ?", (ctx.guild.id,))
            await db.commit()
        await ctx.send(embed=discord.Embed(
            description=f"✅ Reset all invite counts for **{ctx.guild.name}**.",
            color=0x000000
        ))


async def setup(bot):
    await bot.add_cog(InviteTracking(bot))
